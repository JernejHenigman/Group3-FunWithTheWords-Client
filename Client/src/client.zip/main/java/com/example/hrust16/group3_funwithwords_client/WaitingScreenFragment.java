package com.example.hrust16.group3_funwithwords_client;


import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;


/**
 * A simple {@link Fragment} subclass.
 */
public class WaitingScreenFragment extends Fragment implements ValueEventListener{

    Firebase fb;
    public WaitingScreenFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View returnView =  inflater.inflate(R.layout.fragment_waiting_screen, container, false);
        fb = Constants.myFirebaseRef.child("GameState");
        fb.addValueEventListener(WaitingScreenFragment.this);

        return returnView;
    }


    @Override
    public void onDataChange(DataSnapshot dataSnapshot) {
        if (dataSnapshot.getValue() != null) {
            if (dataSnapshot.getValue().equals("GameInProgress")) {

                FragmentManager fm = getFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.container, new KeyboardFragment());
                ft.commit();
                Constants.myFirebaseRef.child("GameState").removeEventListener(WaitingScreenFragment.this);

            }
        }
    }

    @Override
    public void onCancelled(FirebaseError firebaseError) {

    }
}
