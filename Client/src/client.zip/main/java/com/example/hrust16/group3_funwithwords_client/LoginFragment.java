package com.example.hrust16.group3_funwithwords_client;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;



public class LoginFragment extends Fragment implements ValueEventListener {


    Firebase fb;


    public LoginFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View returnView = inflater.inflate(R.layout.fragment_login, container, false);
        View v = returnView.findViewById(R.id.btnLogon);

        fb = Constants.myFirebaseRef.child("Users");
        fb.addValueEventListener(LoginFragment.this);

        v.setOnClickListener(new View.OnClickListener() {
            //Click on loginButton
            @Override
            public void onClick(View v) {

                EditText name = (EditText) getActivity().findViewById(R.id.name);
                Log.i("Name", name.getText().toString());
                Constants.userName = name.getText().toString();
                Constants.myFirebaseRef.child("ScreenNbr").child(Constants.userName).setValue("UserAdded");

            }
        });
        return returnView;
    }

    @Override
    public void onDataChange(DataSnapshot dataSnapshot) {
        Object value = dataSnapshot.getValue();
        if (value != null) {
            if (value instanceof Long) {
                Constants.uniqueID = (long) value;
                if ((Long) value == 0) { //gameOwner
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.replace(R.id.container, new WaitingScreenFragmentGameOwner());
                    ft.commit();


                } else { //normalPlayer

                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.replace(R.id.container, new WaitingScreenFragment());
                    ft.commit();

                }
                Constants.myFirebaseRef.child("Users").removeValue();
                Constants.myFirebaseRef.child("Users").removeEventListener(LoginFragment.this);
            }

        }
    }

    @Override
    public void onCancelled(FirebaseError firebaseError) {

    }
}
