package com.example.hrust16.group3_funwithwords_client;


import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;


/**
 * A simple {@linffk Fragment} subclass.
 */
public class WaitingScreenFragmentGameOwner extends Fragment {


    public WaitingScreenFragmentGameOwner() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v =  inflater.inflate(R.layout.fragment_waiting_screen_fragment_game_owner, container, false);
        View startGameButton = v.findViewById(R.id.buttonStartGame);
        startGameButton.setOnClickListener(new View.OnClickListener() {
            //Click on loginButton
            @Override
            public void onClick(View v) {

                Constants.myFirebaseRef.child("GameState").setValue("GameInProgress");



                FragmentManager fm = getFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.container, new KeyboardFragment());
                Log.i("Trasaction","Should happened");
                ft.commit();

            }
        });

        return v;
    }


}
