package com.example.hrust16.group3_funwithwords_client;

/**
 * Created by hrust16 on 10/14/15.
 */
public class User {
    private String userName;
    private StringBuffer word;
    private int uniqueID;

    public User(String userName) {
        this.userName = userName;
        this.word = new StringBuffer();
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserName() {
        return this.userName;
    }


    public void addLetter(String letter) {
        this.word.append(letter);
    }

    public void removeLetter() {
        int currentWordLength = word.length();
        if (currentWordLength > 0)
            word.deleteCharAt(currentWordLength - 1);
    }

    public StringBuffer getWord() {
        return word;
    }



}
